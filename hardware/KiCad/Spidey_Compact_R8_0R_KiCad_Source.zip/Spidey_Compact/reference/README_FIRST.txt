START HERE

This package supersedes the earlier V1.12 ECO handoff.

Give the entire ZIP to Astra and ask it to read ASTRA_COMPACT_REDESIGN_INSTRUCTIONS.txt first.

The included V1.11 routed PCB is the known-good electrical/routing reference. The task is now BOTH:
1. apply the USB-C and ADC-clamp corrections, and
2. redesign the board much smaller for PCBWay machine assembly.

Target roughly 20 x 18 mm or smaller if practical; do not sacrifice correctness to hit that number.
