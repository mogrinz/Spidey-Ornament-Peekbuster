# IMPORTANT R8 ECO - 0R JUMPER (NEW MANUFACTURING REVISION)

R8 is now a **0-ohm 0603 jumper** (Yageo `RC0603JR-070RL`) in the KiCad PCB, BOM and CPL.
This is the tested fix for the DRV8838 nSLEEP low-voltage condition. The older C1 notes below describe the
prior hardware and may refer to 100k. All layout/manufacturing geometry is unchanged.
The original DRC/verification reports have been renamed `*_ORIGINAL_C1.*` and remain historical:
**native KiCad DRC was not rerun for the value-only ECO**. See `reports/R8_ECO_STATIC_VERIFICATION.txt`.

---

# Spidey Compact C1 — design review package

**Finished PCB: 22.00 × 20.00 mm**, 2 layers, 1.6 mm FR-4, 1 oz copper, lead-free HASL. Area is 440 mm², 41.3% below the 30 × 25 mm reference. All fitted components are on top. There are no mounting holes. The USB metal body projects approximately 0.46 mm beyond the top board edge.

Open `Spidey_Compact.kicad_pro` in **KiCad 10.0 or later**, then the matching PCB. The included project-local footprint libraries resolve through `fp-lib-table`. This is a PCB project: the supplied handoff contained no schematic, and no schematic or firmware is represented as validated by this package. The complete audited pad/net table is in `reports/ELECTRICAL_AUDIT.txt`.

## What changed

- Rebuilt the physical layout from the supplied electrically known-good V1.11 reference. Kept the charger, switched battery supply, MCU pin assignments, motor PH/EN interface, and audio bias/coupling network.
- J1 is the official KiCad 10.0.6 HRO TYPE-C-31-M-12 footprint, with 16 contacts, four plated slotted shell anchors, and two locating holes. Six data/SBU contacts remain unconnected. All four VBUS contacts connect to USB_5V; all four grounds and shell tabs connect to GND. CC1/CC2 retain separate 5.1 kΩ pulldowns. Its placement is based on the HRO drawing's board-edge location, not the old placeholder origin.
- Removed BAT54S D1. D1L and D1H are **BAT54WS-7-F**, SOD-323. D1L K=AUDIO_ADC, A=GND. D1H K=SYS, A=AUDIO_ADC.
- Retained **ATTINY402-SSNR**, SOIC-8. A production ATtiny402 VDFN-8 ordering option could not be verified. No different MCU or USB programming circuit was substituted.
- U2 uses the official TI DSG0008A WSON footprint with a **0.9 × 1.6 mm exposed ground pad** and divided paste apertures. There are no open vias in its exposed solder pad.
- D2 uses the standard LED footprint convention: pin 1 is cathode/STAT; pin 2 is anode/LED_A. This preserves the old LED function despite the reference footprint's reversed numbering.
- Reduced C6 from 220 µF to **47 µF, 6.3 V polymer**, KEMET T520A476M006ATE150, EIA 3216-18, specified 150 mΩ ESR. Pin 1 is positive/SYS. All local 100 nF capacitors remain. MCU decoupling has a direct short supply connection.
- All resistors, ceramic capacitors, and the charge LED use 0603 packages. C8 remains **DNP**; it is excluded from the placement file.
- Replaced external connectors with 1.30 mm plated wire pads, 0.65 mm finished holes. J7 is three 1.00 mm backside pogo pads at 1.50 mm pitch, with no paste.
- Added copper ground pours on both layers, tented 0.60/0.30 mm vias, and backside wiring labels. Minimum routed track width is 0.25 mm; supply trunks widen where space permits. Copper clearance is 0.20 mm, copper-to-edge clearance 0.25 mm, and minimum solder-mask web 0.10 mm. Ground pads use direct pour connections.
- Reference designators are retained in the PCB and fabrication layer. Top silkscreen shows component polarity marks, CHG, and the board name; backside silkscreen carries wiring labels. Only J1's silkscreen lines beyond the PCB edge were trimmed; its production copper, holes, paste, fabrication outline, and courtyard remain the official geometry. The bundled matching footprint includes that silkscreen trim.

## Wiring

| Feature | Pin | Connection / label |
|---|---:|---|
| J2 BAT | 1 | BAT_RAW, battery positive, `+` |
| J2 BAT | 2 | GND, battery negative, `-` |
| J5 SW | 1 | BAT_RAW, `B` |
| J5 SW | 2 | SYS, `S` |
| J4 PWR | 1 | SYS / `PWR+`, original ornament positive |
| J4 PWR | 2 | GND |
| J3 MOTOR | 1 | MOTOR_A / `M-A` |
| J3 MOTOR | 2 | MOTOR_B / `M-B` |
| J6 SPKR | 1 | SPKR_SENSE |
| J7 pogo | 1 | UPDI / `U` |
| J7 pogo | 2 | SYS / `+` |
| J7 pogo | 3 | GND / `-` |

The external SPST switch goes between J5 pins 1 and 2. Use a protected 1S LiPo. Speaker sense shares the ornament's ground through J4. The battery adapter may be wired to suit the cable polarity. Suggested wire size is 28–30 AWG; verify the actual stranded-wire bundle fits a 0.65 mm finished hole. Provide external wire strain relief.

## Assembly files

`BOM.csv` specifies exact MPNs and FIT/DNP status. Quantities are per board; order for five assembled prototypes plus PCBWay's required attrition allowance. Wire/pogo features require no purchased parts.

`CPL.csv` is the native KiCad front-side position export, in mm. Its origin is the **top-left PCB corner**, X increases right and Y increases upward, so positions on the board have negative Y. Rotation is KiCad's native counterclockwise convention as viewed from the front. J1 is included even though it has through-hole shell tabs. PCBWay must map rotation and pin 1 to its machine libraries; do not infer component orientation from tape-feed direction.

`Front_Assembly.svg` shows the fabrication outlines and references, with diode reference labels repositioned for readability. `Back_Wiring.svg` is mirrored into a true view from the rear. These are review drawings, not manufacturing Gerbers.

## Verification and remaining pre-Gerber items

The delivered native KiCad DRC reports and pin/net audit are in `reports/`. DRC checks electrical connectivity, copper spacing, mask bridges, courtyards, footprint-library consistency, and silkscreen. No violations were waived or excluded. The report lists KiCad’s default ignored check categories; no schematic-to-PCB parity check is claimed. The audit compares every retained pin assignment with V1.11 and explicitly checks the required exceptions.

Before generating Gerbers:

1. Review this redesign and confirm enclosure fit, USB insertion/overhang, backside UPDI access, and wire access. Check the actual HRO connector drawing against PCBWay's procured C165948 part; do not substitute an unspecified “16-pin USB-C.”
2. Have PCBWay confirm exact-part availability, especially the KEMET polymer capacitor, and approve the BOM/CPL orientations, LED cathode, clamp cathodes, capacitor positive terminal, USB shell soldering process, and WSON exposed-pad paste/reflow process. No stock reservation or factory DFM review has been performed.
3. Request a PCBWay assembly panel with tooling rails and three global fiducials. This small finished PCB intentionally has no tooling holes or board-level fiducials. Have the assembler approve panelization, edge handling, lead-free HASL on the fine-pitch WSON/USB lands, and stencil design. The 22 × 20 mm dimensions exclude that temporary panel frame.
4. Scope SYS at U1/U2 during motor start, reversal, and the measured 142 mA brief stall, including a low battery and actual wire lengths. **47 µF is a prototype engineering choice, not a measured transient validation.** As a scale check, 142 mA supplied by 47 µF alone for 100 µs produces about 0.30 V droop, plus roughly 0.021 V ESR step at 150 mΩ. The battery supplies sustained current. If supply droop or resets occur, re-evaluate bulk capacitance, wiring impedance, and firmware sequencing before production.
5. Confirm charging current and termination with the intended battery. R3=10 kΩ retains approximately 100 mA charging. The preserved MCP73831 architecture has no separate load-sharing power path; test charge termination with the switch off and with any intended simultaneous load.
6. Bench-test audio ADC bias, clipping, input amplitude, motor-noise pickup, both motor directions, UPDI programming, and MCU brownout settings. Firmware and assembled hardware were not available for testing. Leave C8 unpopulated unless a measured EMI need and driver behavior justify fitting it.

**No Gerbers or production order are included.**

## Package verification sources

- Microchip ATtiny202/204/402/404/406 data sheet DS40002318A: https://ww1.microchip.com/downloads/en/DeviceDoc/ATtiny202-204-402-404-406-DataSheet-DS40002318A.pdf
- TI DRV8838 data sheet and DSG package drawings: https://www.ti.com/lit/ds/symlink/drv8838.pdf
- Microchip MCP73831 family DS20001984H: https://www.microchip.com/content/dam/mchp/documents/APID/ProductDocuments/DataSheets/MCP73831-Family-Data-Sheet-DS20001984H.pdf
- Diodes Incorporated BAT54WS: https://www.diodes.com/datasheet/download/BAT54WS.pdf
- HRO TYPE-C-31-M-12 mechanical drawing via LCSC: https://datasheet.lcsc.com/datasheet/pdf/9e56b777c022540fcce7c7f67825f55e.pdf
- KEMET T52X/T530 polymer capacitor data sheet: https://www.yageogroup.com/content/datasheet/asset/file/KEM_T2076_T52X-530
- Yageo 100 nF 0603 capacitor specification: https://yageogroup.com/download/specsheet/CC0603KRX7R9BB104
- Lite-On LTST-C190KGKT: https://optoelectronics.liteon.com/upload/download/DS22-2000-074/LTST-C190KGKT.PDF
- Official footprints: KiCad 10.0.6 footprint-library release; bundled footprint files retain their upstream metadata. KiCad library licensing permits inclusion in PCB designs; see `footprints/LICENSE.md`.
